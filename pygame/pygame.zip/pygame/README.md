This game is basically the demonstration from class. 
The Death Star is able to move all around the screen using the arrow keys, and can fire its lasers by clicking the mouse. Unlike the example from class, this Death Star can aim while shooting, so it is not locked in a position when shooting. 

You can press the 'r' key to reset the game.
