from DeathStar import *
from Earth import *
from Laser import *
from Explosion import *
